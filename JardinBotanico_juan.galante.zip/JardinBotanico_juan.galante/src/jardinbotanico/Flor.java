
package jardinbotanico;


public class Flor extends Planta{
    
    private TemporadaFlorecimiento temporada;

    public Flor(TemporadaFlorecimiento temporada, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }
    
    
    public void podar(){
        System.out.println("Las flores no pueden ser podadas");
    }

    @Override
    public String toString() {
        return super.toString() + "Flor{" + "temporada=" + temporada + '}';
    }

}
