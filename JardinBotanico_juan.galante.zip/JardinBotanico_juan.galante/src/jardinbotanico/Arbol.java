
package jardinbotanico;


public class Arbol extends Planta {

   
    private static final int ALTURA_MAXIMA = 10;
    private int altura;

     public Arbol(int altura, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
         validarAltura(altura);
        this.altura = altura;
    }
    
    @Override
     public void podar(){
         System.out.println("Podando Arbol");
     }
     
     private void validarAltura(int altura){
         if(altura > ALTURA_MAXIMA){
             throw new RuntimeException("La altura maxima es 10");
         }
     
     }
     
    @Override
    public String toString() {
        return super.toString() + "Arbol{" + "altura=" + altura + '}';
    }
    
    
    
}
