
package jardinbotanico;


public class TestJardinBotanico {

   
    public static void main(String[] args) {
        
        JardinBotanico jardin = new JardinBotanico();
        
        
        Arbol arbol_1 = new Arbol(5, "roble", "norte", "templado");
        Arbol arbol_2 = new Arbol(7, "jacaranda", "norte", "templado");
        Arbol arbol_3 = new Arbol(5, "roble", "norte", "templado");
        Arbusto arbusto_1 = new Arbusto(5, "ficus", "norte", "templado");
        Arbusto arbusto_2 = new Arbusto(6, "libustrina", "norte", "templado");
        Arbusto arbusto_3 = new Arbusto(5, "KKK", "norte", "templado");
        Flor flor_1 = new Flor(TemporadaFlorecimiento.INVIERNO, "Rosa", "sur", "calor");
        Flor flor_2 = new Flor(TemporadaFlorecimiento.VERANO, "Jazmin", "norte", "calor");
        Flor flor_3 = new Flor(TemporadaFlorecimiento.OTONIO, "Rosa", "norte", "calor");
        
        
        try{
        jardin.agregarPlanta(flor_1);
        jardin.agregarPlanta(flor_2);
        jardin.agregarPlanta(flor_3);
        jardin.agregarPlanta(arbol_1);
        jardin.agregarPlanta(arbol_2);
        jardin.agregarPlanta(arbusto_1);
        jardin.agregarPlanta(arbusto_2);
        jardin.agregarPlanta(arbusto_3);
        jardin.agregarPlanta(arbol_3);
        } catch (PlantaRepetidaException ex){
            System.out.println(ex.getMessage());
        } 
       
        
        System.out.println("---------------------------------");
        
        jardin.mostrarPlantas();
        
        System.out.println("---------------------------------");
        
        jardin.podarPlantas();

    }
    
}
