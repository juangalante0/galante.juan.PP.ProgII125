
package jardinbotanico;

public class PlantaRepetidaException extends RuntimeException {
    
    
    private static final String MENSAJE = "La planta ya se encuentra en el jardin";
    
    public PlantaRepetidaException() {
        super(MENSAJE);
    }
    
    
}
