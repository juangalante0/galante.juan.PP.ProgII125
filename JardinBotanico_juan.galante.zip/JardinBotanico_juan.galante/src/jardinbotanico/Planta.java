
package jardinbotanico;


public abstract class Planta {
    
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    
    public boolean equals(Object o){
        if(o == this){
        return true;
        }
        
        if(o == null || getClass() != o.getClass()){
            return false;
        }
        
        Planta otraPlanta = (Planta) o;
        
        return nombre.equals(otraPlanta.nombre) && ubicacion.equals(otraPlanta.ubicacion);
    }
    
    public abstract void podar();

    @Override
    public String toString() {
        return "Planta{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", clima=" + clima + '}';
    }

    
    
    
    

}
